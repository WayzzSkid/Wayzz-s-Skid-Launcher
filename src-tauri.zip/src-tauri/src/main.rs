#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use std::env;
use std::fs::create_dir_all;
use sysinfo::System;
use tauri::{AppHandle, Manager, Window};
mod carter;
use dotenvy::dotenv;

#[tauri::command]
fn close_launcher(app: tauri::AppHandle) {
    app.exit(0);
}

#[tauri::command]
fn window_minimize(window: Window) {
    window.minimize().unwrap();
}

#[tauri::command]
fn window_close(window: Window) {
    window.close().unwrap();
}

#[tauri::command]
async fn firstlaunch(
    path: String,
    app: AppHandle,
    email: String,
    password: String,
    eor: bool,
    disable_pre_edits: bool,
) -> Result<bool, String> {
    if !carter::security_check() {
        return Err("Security violation: Debugger detected.".to_string());
    }
    carter::kill();
    carter::kill_epic();
    let dll_url = env::var("VITE_REDIRECT_LINK").unwrap_or_default();
    let mut inject_dlls = env::var("VITE_INJECT_DLLS_LINKS").unwrap_or_default();
    let paks = env::var("VITE_PAKS_AND_SIGS_LINKS").unwrap_or_default();

    if eor {
        let eor_dll = env::var("VITE_EOR_DLL_LINK").unwrap_or_default();
        if !eor_dll.is_empty() {
            if inject_dlls.is_empty() { inject_dlls = eor_dll; } else { inject_dlls = format!("{},{}", inject_dlls, eor_dll); }
        }
    }
    if disable_pre_edits {
        let pre_dll = env::var("VITE_DISABLE_PRE_EDITS_DLL_LINK").unwrap_or_default();
        if !pre_dll.is_empty() {
            if inject_dlls.is_empty() { inject_dlls = pre_dll; } else { inject_dlls = format!("{},{}", inject_dlls, pre_dll); }
        }
    }
    carter::launch_fn(&path, dll_url, inject_dlls, paks, app, email, password, eor).await
}

#[tauri::command]
fn is_fortnite_client_running() -> bool {
    let mut system = System::new_all();
    system.refresh_all();
    for (_, process) in system.processes() {
        if process.name().to_string_lossy().contains("FortniteClient-Win64-Shipping.exe") {
            return true;
        }
    }
    false
}

#[tauri::command]
fn kill_fortnite() {
    carter::kill();
}

#[tauri::command]
fn scan_injectors(detection_enabled: Option<bool>) -> Option<String> {
    let enabled = detection_enabled.unwrap_or_else(|| {
        std::env::var("VITE_INJECTOR_DETECTION")
            .unwrap_or_else(|_| "true".to_string()) == "true"
    });
    if !enabled {
        return None;
    }
    let blacklist = [
        "injector", "cheatengine", "cheat engine", "x64dbg", "x32dbg",
        "ollydbg", "ida64", "ida32", "processhacker", "process hacker",
        "extremeinjector", "xenos", "xenosinjector", "gdinjector",
        "dllinjector", "manualmap", "ghostinjector", "uberinjector",
        "winject", "remoteinjector", "simpledllinjector", "dllspoofer",
        "dllhijack", "dllloader", "dllmapper", "dllpatcher",
        // UUU and camera tools
        "uuuclient", "uuu", "otis_inf", "igcsdll", "igcs",
        "frameshotclient", "frameshotserver",
        // Common cheat loaders
        "loader", "bypass", "spoofer", "hwid", "kiero",
        "minhook", "detours", "polyhook", "safetyhook",
        // Debug / reverse engineering
        "reclass", "reclassnet", "cheatengine-x86_64",
        "scyllahide", "titanhide", "dbgview",
        "windbg", "dnspy", "dotpeek", "ilspy",
        // Known FN cheats
        "fiddler", "proxifier", "charles",
    ];
    let mut system = System::new_all();
    system.refresh_all();
    for (_, process) in system.processes() {
        let name = process.name().to_string_lossy().to_lowercase();
        for bad in &blacklist {
            if name.contains(bad) {
                return Some(process.name().to_string_lossy().to_string());
            }
        }
    }
    None
}

#[tokio::main]
async fn main() {
    let env_content = include_str!("../../.env");
    for line in env_content.lines() {
        if line.starts_with('#') || line.trim().is_empty() { continue; }
        if let Some((key, value)) = line.split_once('=') {
            let clean_value = value.trim().trim_matches('"');
            std::env::set_var(key.trim(), clean_value);
        }
    }
    dotenv().ok();

    carter::start_discord_rpc();

    let app_name = env::var("VITE_LAUNCHER_NAME").unwrap_or_else(|_| "Project".to_string());
    let path = format!("C:\\Program Files\\{}", app_name);
    if let Err(e) = create_dir_all(&path) {
        eprintln!("Error creating directory: {}", e);
    }

    tauri::Builder::default()
        .setup(|app| {
            let window = app.get_window("main").unwrap();
            window.on_window_event(|event| {
                if let tauri::WindowEvent::CloseRequested { .. } = event {
                    carter::kill();
                }
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            window_minimize,
            window_close,
            firstlaunch,
            is_fortnite_client_running,
            kill_fortnite,
            scan_injectors,
            close_launcher,
            carter::download_paks_cmd,
            carter::delete_bubble_paks
        ])
        .run(tauri::generate_context!())
        .expect("Error starting the app");
}
